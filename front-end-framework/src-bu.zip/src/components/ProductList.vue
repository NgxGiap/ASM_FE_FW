<template>
  <div class="container mt-4">
    <h2 class="text-center">Danh sách sản phẩm</h2>
    <table class="table table-striped table-hover mt-4">
      <thead>
        <tr>
          <th>ID</th>
          <th>Hình ảnh</th>
          <th>Tên sản phẩm</th>
          <th>Mô tả</th>
          <th>Giá</th>
          <th>Trạng thái</th>
          <th>Hành động</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="product in products" :key="product.id">
          <td>{{ product.id }}</td>
          <td>
            <img :src="product.image" alt="Product Image" class="img-thumbnail" style="width: 80px; height: 80px;" />
          </td>
          <td>{{ product.name }}</td>
          <td>{{ product.description }}</td>
          <td>{{ product.price }}</td>
          <td>
            <span :class="product.status === 'Available' ? 'badge bg-success' : 'badge bg-secondary'">
              {{ product.status }}
            </span>
          </td>
          <td>
            <button class="btn btn-info btn-sm" @click="viewProduct(product.id)">Xem</button>
            <button class="btn btn-warning btn-sm" @click="editProduct(product.id)">Sửa</button>
            <button class="btn btn-danger btn-sm" @click="deleteProduct(product.id)">Xóa</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: 'ProductList',
  data() {
    return {
      products: [
        {
          id: 1,
          image: 'https://via.placeholder.com/80', // Thay bằng link hình ảnh sản phẩm thực tế
          name: 'Spaghetti Carbonara',
          description: 'Classic Italian pasta with a creamy sauce.',
          price: '$14.00',
          status: 'Available'
        },
        // Thêm các sản phẩm khác ở đây...
      ]
    };
  },
  methods: {
    viewProduct(id) {
      this.$router.push(`/products/${id}`);
    },
    editProduct(id) {
      this.$router.push(`/products/edit/${id}`);
    },
    deleteProduct(id) {
      // Thêm logic xóa sản phẩm tại đây
      alert(`Xóa sản phẩm với ID: ${id}`);
    }
  }
};
</script>

<style>
.table {
  width: 100%;
}
</style>
