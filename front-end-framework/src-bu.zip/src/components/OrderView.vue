<template>
    <div class="container">
      <h2>Chi tiết đơn hàng</h2>
      <p><strong>ID:</strong> {{ order.id }}</p>
      <p><strong>ID Sản phẩm:</strong> {{ order.productId }}</p>
      <p><strong>Số lượng:</strong> {{ order.quantity }}</p>
      <p><strong>Tổng giá:</strong> {{ order.totalPrice }}</p>
      <button class="btn btn-primary" @click="goBack">Quay lại</button>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        order: {}
      };
    },
    async mounted() {
      const response = await axios.get(`http://localhost:3000/orders/${this.$route.params.id}`);
      this.order = response.data;
    },
    methods: {
      goBack() {
        this.$router.push('/orders');
      }
    }
  };
  </script>
  