<template>
  <div class="container mt-4">
    <h2>{{ isEdit ? 'Chỉnh sửa Sản phẩm' : 'Thêm Sản phẩm Mới' }}</h2>
    <form @submit.prevent="submitForm">
      <div class="mb-3">
        <label for="name" class="form-label">Tên sản phẩm</label>
        <input type="text" id="name" v-model="product.name" class="form-control" required />
      </div>
      <div class="mb-3">
        <label for="description" class="form-label">Mô tả</label>
        <textarea id="description" v-model="product.description" class="form-control" required></textarea>
      </div>
      <div class="mb-3">
        <label for="price" class="form-label">Giá</label>
        <input type="number" id="price" v-model="product.price" class="form-control" required />
      </div>
      <div class="mb-3">
        <label for="status" class="form-label">Trạng thái</label>
        <select id="status" v-model="product.status" class="form-select">
          <option value="Available">Available</option>
          <option value="Unavailable">Unavailable</option>
        </select>
      </div>
      <div class="mb-3">
        <label for="image" class="form-label">Hình ảnh</label>
        <input type="text" id="image" v-model="product.image" class="form-control" placeholder="URL hình ảnh" />
      </div>
      <button type="submit" class="btn btn-primary">{{ isEdit ? 'Cập nhật' : 'Thêm' }}</button>
      <button type="button" class="btn btn-secondary" @click="cancel">Hủy</button>
    </form>
  </div>
</template>

<script>
export default {
  name: 'ProductForm',
  data() {
    return {
      isEdit: false, // Cập nhật biến này dựa trên logic route hoặc props
      product: {
        name: '',
        description: '',
        price: 0,
        status: 'Available',
        image: ''
      }
    };
  },
  methods: {
    submitForm() {
      if (this.isEdit) {
        // Logic cập nhật sản phẩm
        alert('Cập nhật sản phẩm thành công!');
      } else {
        // Logic thêm sản phẩm mới
        alert('Thêm sản phẩm thành công!');
      }
      this.$router.push('/products');
    },
    cancel() {
      this.$router.push('/products');
    }
  }
};
</script>
