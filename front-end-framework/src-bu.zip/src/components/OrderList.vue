<template>
    <div class="container">
      <h2>Danh sách đơn hàng</h2>
      <button class="btn btn-primary" @click="goToAddOrder">Thêm đơn hàng mới</button>
      <table class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>ID Sản phẩm</th>
            <th>Số lượng</th>
            <th>Tổng giá</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="order in orders" :key="order.id">
            <td>{{ order.id }}</td>
            <td>{{ order.productId }}</td>
            <td>{{ order.quantity }}</td>
            <td>{{ order.totalPrice }}</td>
            <td>
              <button class="btn btn-info" @click="viewOrder(order.id)">Xem</button>
              <button class="btn btn-warning" @click="editOrder(order.id)">Sửa</button>
              <button class="btn btn-danger" @click="deleteOrder(order.id)">Xóa</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        orders: []
      };
    },
    mounted() {
      this.fetchOrders();
    },
    methods: {
      async fetchOrders() {
        const response = await axios.get('http://localhost:3000/orders');
        this.orders = response.data;
      },
      goToAddOrder() {
        this.$router.push('/orders/add');
      },
      viewOrder(id) {
        this.$router.push(`/orders/${id}`);
      },
      editOrder(id) {
        this.$router.push(`/orders/edit/${id}`);
      },
      async deleteOrder(id) {
        await axios.delete(`http://localhost:3000/orders/${id}`);
        this.fetchOrders();
      }
    }
  };
  </script>
  