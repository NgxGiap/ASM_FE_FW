<template>
    <div class="container">
      <h2>{{ isEditMode ? 'Chỉnh sửa đơn hàng' : 'Thêm đơn hàng mới' }}</h2>
      <form @submit.prevent="saveOrder">
        <div class="form-group">
          <label>ID Sản phẩm</label>
          <input v-model="order.productId" type="number" class="form-control" required />
        </div>
        <div class="form-group">
          <label>Số lượng</label>
          <input v-model="order.quantity" type="number" class="form-control" required />
        </div>
        <div class="form-group">
          <label>Tổng giá</label>
          <input v-model="order.totalPrice" type="number" class="form-control" required />
        </div>
        <button class="btn btn-success">{{ isEditMode ? 'Cập nhật' : 'Thêm' }}</button>
      </form>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        order: {
          productId: '',
          quantity: 1,
          totalPrice: 0
        },
        isEditMode: false
      };
    },
    async mounted() {
      if (this.$route.params.id) {
        this.isEditMode = true;
        const response = await axios.get(`http://localhost:3000/orders/${this.$route.params.id}`);
        this.order = response.data;
      }
    },
    methods: {
      async saveOrder() {
        if (this.isEditMode) {
          await axios.put(`http://localhost:3000/orders/${this.$route.params.id}`, this.order);
        } else {
          await axios.post('http://localhost:3000/orders', this.order);
        }
        this.$router.push('/orders');
      }
    }
  };
  </script>
  