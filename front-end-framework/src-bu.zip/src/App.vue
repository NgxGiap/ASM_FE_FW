<template>
  <div id="app">
    <nav>
      <router-link to="/products">Quản lý Sản phẩm</router-link> |
      <router-link to="/orders">Quản lý Đơn hàng</router-link>
    </nav>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
};
</script>

<style>
nav {
  margin: 20px;
}
</style>
