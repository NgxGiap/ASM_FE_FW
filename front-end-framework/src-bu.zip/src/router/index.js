// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import Products from '../views/Products.vue';
import Orders from '../views/Orders.vue';
import ProductList from '../components/ProductList.vue';
import ProductForm from '../components/ProductForm.vue';
import ProductView from '../components/ProductView.vue';
import OrderList from '../components/OrderList.vue';
import OrderForm from '../components/OrderForm.vue';
import OrderView from '../components/OrderView.vue';

const routes = [
  {
    path: '/products',
    component: Products,
    children: [
      { path: '', component: ProductList },
      { path: 'add', component: ProductForm },
      { path: 'edit/:id', component: ProductForm },
      { path: ':id', component: ProductView }
    ]
  },
  {
    path: '/orders',
    component: Orders,
    children: [
      { path: '', component: OrderList },
      { path: 'add', component: OrderForm },
      { path: 'edit/:id', component: OrderForm },
      { path: ':id', component: OrderView }
    ]
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
